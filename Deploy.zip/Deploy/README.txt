DFPM, UatSchedTask & UploadSchTasks are used by installer script to add Scheduled Tasks

smconfig.xml is for older Sysmon versions

sysmonconfig.txt is for 10.0.4.1 or higher